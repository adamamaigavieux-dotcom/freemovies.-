package com.example.freemovies.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.freemovies.data.Movie
import com.example.freemovies.data.MovieDetail
import com.example.freemovies.data.MovieRepository
import com.example.freemovies.data.ServiceLocator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

// ---------- Liste des films ----------

data class HomeState(
    val movies: List<Movie> = emptyList(),
    val query: String = "",
    val loading: Boolean = false,
    val endReached: Boolean = false,
    val error: String? = null,
)

class HomeViewModel(
    private val repo: MovieRepository = ServiceLocator.repository,
) : ViewModel() {

    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state.asStateFlow()

    private var page = 1

    init {
        load(reset = true)
    }

    fun onQueryChange(query: String) = _state.update { it.copy(query = query) }

    fun search() = load(reset = true)

    fun loadMore() {
        val s = _state.value
        if (!s.loading && !s.endReached) load(reset = false)
    }

    private fun load(reset: Boolean) {
        viewModelScope.launch {
            if (reset) page = 1
            _state.update { it.copy(loading = true, error = null) }
            try {
                val result = repo.movies(_state.value.query, page)
                page++
                _state.update {
                    it.copy(
                        movies = if (reset) result else it.movies + result,
                        loading = false,
                        endReached = result.size < MovieRepository.PAGE_SIZE,
                    )
                }
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = "Impossible de charger les films. Vérifie ta connexion.") }
            }
        }
    }
}

// ---------- Détail d'un film ----------

data class DetailState(
    val detail: MovieDetail? = null,
    val loading: Boolean = true,
    val error: String? = null,
)

class DetailViewModel(
    private val id: String,
    private val repo: MovieRepository = ServiceLocator.repository,
) : ViewModel() {

    private val _state = MutableStateFlow(DetailState())
    val state: StateFlow<DetailState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                _state.value = DetailState(detail = repo.detail(id), loading = false)
            } catch (e: Exception) {
                _state.value = DetailState(loading = false, error = "Impossible de charger ce film.")
            }
        }
    }
}
