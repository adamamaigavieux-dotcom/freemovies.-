# FreeMovies

Application Android de films gratuits et légaux, construite avec Kotlin, Jetpack Compose, Media3 (ExoPlayer) et Retrofit.
La source de contenu est la collection « Feature Films » de l'Internet Archive.

## Lancer le projet

1. Installe [Android Studio](https://developer.android.com/studio) (version récente).
2. `File > Open` et choisis le dossier `FreeMovies`. Accepte la synchronisation Gradle (elle télécharge les dépendances, il faut une connexion internet).
3. Branche un téléphone (débogage USB activé) ou lance un émulateur, puis clique sur ▶ Run.

## Structure

```
app/src/main/java/com/example/freemovies/
├── MainActivity.kt          # Navigation : liste → détail → lecteur
├── data/
│   ├── ArchiveApi.kt        # Appels Retrofit (recherche + métadonnées)
│   ├── Category.kt          # Catégories (Tous, Comédie, Horreur, Documentaire)
│   ├── Models.kt            # Modèles JSON et modèles d'interface
│   ├── MovieRepository.kt   # Logique : liste paginée, détail, choix du fichier MP4
│   └── ServiceLocator.kt    # Création de Retrofit / du repository
└── ui/
    ├── ViewModels.kt        # État des écrans (liste, détail)
    ├── HomeScreen.kt        # Grille d'affiches + recherche + pagination
    ├── DetailScreen.kt      # Fiche du film + bouton Regarder
    └── PlayerScreen.kt      # Lecteur vidéo ExoPlayer
```

## Point important : droits d'auteur

La collection `feature_films` contient surtout des films du domaine public, mais l'Internet Archive ne garantit pas
que chaque élément le soit. Avant de publier l'app sur le Play Store :

- vérifie le statut de chaque film, ou limite la liste à des identifiants que tu as contrôlés (ou à des films avec une licence Creative Commons explicite) ;
- affiche la licence quand elle existe (l'écran détail le fait déjà via `licenseurl`) ;
- lis les conditions d'utilisation de l'Internet Archive et, si tu ajoutes TMDB pour les affiches, les leurs.

## Idées pour la suite

- Favoris et reprise de lecture (Room ou DataStore)
- Autres catégories (science-fiction, western, animation…) : ajoute une ligne dans `data/Category.kt`. Les catégories filtrent sur le champ « subject » de l'Internet Archive : si une catégorie renvoie peu de films, ajuste ses mots-clés ou élargis la recherche à d'autres collections
- Sous-titres, mode paysage plein écran, Picture-in-Picture
- Publicité (AdMob) pour financer l'app
- Écran d'accueil avec un carrousel « À la une »
