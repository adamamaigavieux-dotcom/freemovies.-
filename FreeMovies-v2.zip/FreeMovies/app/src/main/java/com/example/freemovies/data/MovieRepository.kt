package com.example.freemovies.data

class MovieRepository(private val api: ArchiveApi) {

    companion object {
        const val PAGE_SIZE = 40
        private const val BASE_QUERY = "collection:feature_films AND mediatype:movies"
    }

    /** Liste paginée de films, triés par popularité. [query] filtre sur le titre, [category] sur le genre. */
    suspend fun movies(query: String, category: Category, page: Int): List<Movie> {
        // On retire les caractères spéciaux de la syntaxe de recherche pour éviter les requêtes invalides.
        val clean = query.replace(Regex("[^\\p{L}\\p{N} ]"), " ").trim()

        val q = buildString {
            append(BASE_QUERY)
            if (category.subjects.isNotEmpty()) {
                append(" AND subject:(")
                append(category.subjects.joinToString(" OR ") { "\"$it\"" })
                append(")")
            }
            if (clean.isNotEmpty()) append(" AND title:($clean)")
        }

        val response = api.search(
            query = q,
            fields = listOf("identifier", "title", "year"),
            sort = "downloads desc",
            rows = PAGE_SIZE,
            page = page,
        )
        return response.response.docs.map {
            Movie(
                id = it.identifier,
                title = it.title.asText() ?: it.identifier,
                year = it.year.asText(),
            )
        }
    }

    /** Détails d'un film + URL de lecture du premier fichier MP4 trouvé. */
    suspend fun detail(id: String): MovieDetail {
        val meta = api.metadata(id)
        val video = meta.files
            .filter { it.name.endsWith(".mp4", ignoreCase = true) }
            // On préfère l'encodage h.264 s'il existe, sinon le premier MP4.
            .sortedByDescending { it.format.equals("h.264", ignoreCase = true) }
            .firstOrNull()

        return MovieDetail(
            id = id,
            title = meta.metadata.title.asText() ?: id,
            year = meta.metadata.year.asText(),
            description = meta.metadata.description.asText()?.stripHtml().orEmpty(),
            videoUrl = video?.let { "https://archive.org/download/$id/${encodePath(it.name)}" },
            licenseUrl = meta.metadata.licenseurl.asText(),
        )
    }
}
