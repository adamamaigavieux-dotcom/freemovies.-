package com.example.freemovies.data

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface ArchiveApi {

    @GET("advancedsearch.php")
    suspend fun search(
        @Query("q") query: String,
        @Query("fl[]") fields: List<String>,
        @Query("sort[]") sort: String,
        @Query("rows") rows: Int,
        @Query("page") page: Int,
        @Query("output") output: String = "json",
    ): SearchResponse

    @GET("metadata/{id}")
    suspend fun metadata(@Path("id") id: String): MetadataResponse
}
