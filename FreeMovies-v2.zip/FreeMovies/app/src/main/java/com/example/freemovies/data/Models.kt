package com.example.freemovies.data

import android.net.Uri
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull

// --- Réponses de l'API de l'Internet Archive ---

@Serializable
data class SearchResponse(val response: SearchBody)

@Serializable
data class SearchBody(
    val numFound: Int = 0,
    val docs: List<SearchDoc> = emptyList(),
)

// title / year peuvent être une chaîne, un nombre ou une liste selon l'item : on lit du JSON brut.
@Serializable
data class SearchDoc(
    val identifier: String,
    val title: JsonElement? = null,
    val year: JsonElement? = null,
)

@Serializable
data class MetadataResponse(
    val files: List<ArchiveFile> = emptyList(),
    val metadata: MetadataInfo = MetadataInfo(),
)

@Serializable
data class ArchiveFile(
    val name: String,
    val format: String? = null,
    val size: String? = null,
)

@Serializable
data class MetadataInfo(
    val title: JsonElement? = null,
    val description: JsonElement? = null,
    val year: JsonElement? = null,
    val licenseurl: JsonElement? = null,
)

// --- Modèles utilisés par l'interface ---

data class Movie(
    val id: String,
    val title: String,
    val year: String?,
) {
    val posterUrl: String get() = "https://archive.org/services/img/$id"
}

data class MovieDetail(
    val id: String,
    val title: String,
    val year: String?,
    val description: String,
    val videoUrl: String?,
    val licenseUrl: String?,
) {
    val posterUrl: String get() = "https://archive.org/services/img/$id"
}

// --- Utilitaires ---

fun JsonElement?.asText(): String? = when (this) {
    null -> null
    is JsonPrimitive -> contentOrNull
    is JsonArray -> firstOrNull().asText()
    else -> null
}

private val htmlTag = Regex("<[^>]*>")

fun String.stripHtml(): String = replace(htmlTag, " ").replace(Regex("\\s+"), " ").trim()

fun encodePath(path: String): String = Uri.encode(path, "/")
