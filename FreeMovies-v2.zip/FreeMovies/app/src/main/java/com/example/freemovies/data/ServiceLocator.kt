package com.example.freemovies.data

import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory

/** Fournit les dépendances réseau. Pour un vrai projet, remplace-le par Hilt ou Koin. */
object ServiceLocator {

    private val json = Json {
        ignoreUnknownKeys = true
        isLenient = true
    }

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl("https://archive.org/")
            .client(OkHttpClient.Builder().build())
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
    }

    val repository: MovieRepository by lazy {
        MovieRepository(retrofit.create(ArchiveApi::class.java))
    }
}
