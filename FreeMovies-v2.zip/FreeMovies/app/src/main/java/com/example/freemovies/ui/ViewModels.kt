package com.example.freemovies.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.freemovies.data.Category
import com.example.freemovies.data.Movie
import com.example.freemovies.data.MovieDetail
import com.example.freemovies.data.MovieRepository
import com.example.freemovies.data.ServiceLocator
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

// ---------- Liste des films ----------

data class HomeState(
    val movies: List<Movie> = emptyList(),
    val query: String = "",
    val category: Category = Category.ALL,
    val loading: Boolean = false,
    val endReached: Boolean = false,
    val error: String? = null,
)

class HomeViewModel(
    private val repo: MovieRepository = ServiceLocator.repository,
) : ViewModel() {

    private val _state = MutableStateFlow(HomeState())
    val state: StateFlow<HomeState> = _state.asStateFlow()

    private var page = 1
    private var job: Job? = null

    init {
        load(reset = true)
    }

    fun onQueryChange(query: String) = _state.update { it.copy(query = query) }

    fun onCategoryChange(category: Category) {
        if (category == _state.value.category) return
        _state.update { it.copy(category = category) }
        load(reset = true)
    }

    fun search() = load(reset = true)

    fun loadMore() {
        val s = _state.value
        if (!s.loading && !s.endReached) load(reset = false)
    }

    private fun load(reset: Boolean) {
        job?.cancel()
        job = viewModelScope.launch {
            if (reset) page = 1
            _state.update { it.copy(loading = true, error = null) }
            try {
                val result = repo.movies(_state.value.query, _state.value.category, page)
                page++
                _state.update {
                    it.copy(
                        movies = if (reset) result else it.movies + result,
                        loading = false,
                        endReached = result.size < MovieRepository.PAGE_SIZE,
                    )
                }
            } catch (e: CancellationException) {
                throw e // chargement remplacé par un autre (changement de catégorie) : on ne l'affiche pas comme erreur
            } catch (e: Exception) {
                _state.update { it.copy(loading = false, error = "Impossible de charger les films. Vérifie ta connexion.") }
            }
        }
    }
}

// ---------- Détail d'un film ----------

data class DetailState(
    val detail: MovieDetail? = null,
    val loading: Boolean = true,
    val error: String? = null,
)

class DetailViewModel(
    private val id: String,
    private val repo: MovieRepository = ServiceLocator.repository,
) : ViewModel() {

    private val _state = MutableStateFlow(DetailState())
    val state: StateFlow<DetailState> = _state.asStateFlow()

    init {
        viewModelScope.launch {
            try {
                _state.value = DetailState(detail = repo.detail(id), loading = false)
            } catch (e: Exception) {
                _state.value = DetailState(loading = false, error = "Impossible de charger ce film.")
            }
        }
    }
}
