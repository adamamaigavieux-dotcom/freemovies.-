package com.example.freemovies.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import coil.compose.AsyncImage

@Composable
fun DetailScreen(
    id: String,
    onBack: () -> Unit,
    onPlay: (String) -> Unit,
) {
    val vm: DetailViewModel = viewModel(
        key = id,
        factory = viewModelFactory { initializer { DetailViewModel(id) } },
    )
    val state by vm.state.collectAsState()

    Box(Modifier.fillMaxSize()) {
        val detail = state.detail
        if (detail != null) {
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState()),
            ) {
                AsyncImage(
                    model = detail.posterUrl,
                    contentDescription = detail.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f),
                )
                Column(Modifier.padding(16.dp)) {
                    Text(detail.title, style = MaterialTheme.typography.headlineSmall)
                    detail.year?.let {
                        Text(it, style = MaterialTheme.typography.labelLarge)
                    }

                    Button(
                        onClick = { detail.videoUrl?.let(onPlay) },
                        enabled = detail.videoUrl != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 16.dp),
                    ) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Text(if (detail.videoUrl != null) "Regarder" else "Vidéo indisponible")
                    }

                    Text(detail.description, style = MaterialTheme.typography.bodyMedium)

                    detail.licenseUrl?.let {
                        Text(
                            "Licence : $it",
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier.padding(top = 16.dp),
                        )
                    }
                }
            }
        }

        if (state.loading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center))
        }
        state.error?.let {
            Text(
                it,
                color = MaterialTheme.colorScheme.error,
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
            )
        }

        IconButton(onClick = onBack, modifier = Modifier.padding(8.dp)) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Retour")
        }
    }
}
