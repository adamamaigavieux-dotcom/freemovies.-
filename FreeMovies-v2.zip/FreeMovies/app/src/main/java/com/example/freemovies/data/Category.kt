package com.example.freemovies.data

/**
 * Catégories affichées sous la barre de recherche.
 * [subjects] sont les mots-clés (champ « subject » de l'Internet Archive) utilisés pour filtrer.
 * Pour ajouter une catégorie (western, science-fiction, animation…), ajoute simplement une ligne ici.
 */
enum class Category(val label: String, val subjects: List<String>) {
    ALL("Tous", emptyList()),
    COMEDY("Comédie", listOf("comedy")),
    HORROR("Horreur", listOf("horror")),
    DOCUMENTARY("Documentaire", listOf("documentary", "documentaries")),
}
